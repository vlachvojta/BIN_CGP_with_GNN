import scipty.stats

def beta_mean(a, b):
    return a / (a + b)

